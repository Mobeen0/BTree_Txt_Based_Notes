#pragma once
#include<iostream>
#include<cstdio>
#include<sstream>
#include <fstream>
#include<algorithm>
#include "StacksAndQueue -.h"
#define pow2(n) (1 << (n))

using namespace std;

template <class T>
struct avlNode_ID {
    //Data* key;
    T ID;
    int line;
    string path;
    string left;
    string right;
    mQueue<string> list; //For Duplicates

    avlNode_ID()
    {
        //key = new Data;

        line = 0;
        path = "NULL";
        left = "NULL";
        right = "NULL";
    }

    /*~avlNode_ID()
    {
        delete[] key;
    }*/

    void addData(T id, int l, string p)
    {
        ID = id;
        line = l;
        path = p;
    }

    bool isEmpty()
    {
        if (/*ID == 0 && */line == 0 && path == "NULL" && left == "NULL" && right == "NULL")
            return true;
        else
            return false;
    }

};

fstream& GotoLine(std::fstream& file, unsigned int num) {
    file.seekg(std::ios::beg);
    for (int i = 0; i < num - 1; ++i) {
        file.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }
    return file;
}

//Struct to get and store the contents of each index from file.csv

struct aData {
    int Id; int Year; int Deaths;
    string CauseName113; string CauseName; string State;
    float AadRate;// age adjust death rate
    string path;
    int line;

    aData() {
        MakeNULL();
    }
    void operator=(aData& other) {
        Id = other.Id;
        Year = other.Year;
        Deaths = other.Deaths;
        CauseName113 = other.CauseName113;
        CauseName = other.CauseName;
        State = other.State;
        AadRate = other.AadRate;
    }
    bool operator==(aData& other) {
        if (Id == other.Id)
            return true;
        return false;
    }
    bool operator < (aData& other) {
        if (Id < other.Id)
            return true;
        return false;
    }
    bool operator > (aData& other) {
        if (Id > other.Id)
            return true;
        return false;
    }
    void MakeNULL() {
        Id = 0;
        Year = 0;
        Deaths = 0;
        AadRate = 0;
        CauseName113 = "Empty";
        CauseName = "Empty";
        State = "Empty";
    }

    void Delete()
    {
        string temp_path = "temp_file.txt";
        temp_path = "datafiles/" + temp_path;
        ifstream myfile(path);
        ofstream file_t(temp_path);
        string str_temp;

        if (!file_t)
        {
            ifstream file_t(temp_path);
            file_t.close();

        }

        int c = 0;
        while (c < line)
        {
            str_temp = "";
            getline(myfile, str_temp);
            file_t << str_temp << "\n";
            c++;
        }
        string str = "";
        file_t << str << "\n";

        while (1)
        {
            str_temp = "";
            getline(myfile, str_temp);
            if (str_temp == "")
                break;
            file_t << str_temp << "\n";
        }

        file_t.close();
        myfile.close();

        remove(path.c_str());
        rename(temp_path.c_str(), path.c_str());

    }

    void update(int choice, int Year, int Deaths, string CauseName113, string CauseName, string State, float AadRate)
    {
        if (choice == 1)
        {
            this->Year = Year;
        }
        else if (choice == 2)
        {
            this->Deaths = Deaths;
        }
        else if (choice == 3)
        {
            this->CauseName113 = CauseName113;
        }
        else if (choice == 4)
        {
            this->CauseName = CauseName;
        }
        else if (choice == 5)
        {
            this->State = State;
        }
        else if (choice == 6)
        {
            this->AadRate = AadRate;
        }
        string str;

        str = "";
        str = to_string(this->Id);
        str += ',';
        str += to_string(this->Year);
        str += ',';

        if (this->CauseName113 != "All Causes")
            str += "\"";

        str += this->CauseName113;

        if (this->CauseName113 != "All Causes")
            str += "\"";

        str += ',';
        str += this->CauseName;
        str += ',';
        str += this->State;
        str += ',';
        str += to_string(this->Deaths);
        str += ',';
        str += to_string(this->AadRate);


        string temp_path = "temp_file.txt";
        temp_path = "datafiles/" + temp_path;
        ifstream myfile(path);
        ofstream file_t(temp_path);
        string str_temp;

        if (!file_t)
        {
            ifstream file_t(temp_path);
            file_t.close();

        }

        int c = 0;
        while (c < line)
        {
            str_temp = "";
            getline(myfile, str_temp);
            file_t << str_temp << "\n";
            c++;
        }

        file_t << str << "\n";

        while (1)
        {
            str_temp = "";
            getline(myfile, str_temp);
            if (str_temp == "")
                break;
            file_t << str_temp << "\n";
        }

        file_t.close();
        myfile.close();

        remove(path.c_str());
        rename(temp_path.c_str(), path.c_str());

    }

    void getFromPath(int l = 0, string p = 0)
    {
        line = l;
        path = p;

        string str;
        int stringcounter = 0;
        string tempstr;
        ifstream myfile;

        myfile.open(path);

        for (int i = 0; i < line + 1; i++) // +1 to skip 1st line
        {
            str = "";
            getline(myfile, str); // reading specific line
        }

        if (str != "")
        {

            tempstr = "";
            while (str[stringcounter] != ',') {
                tempstr += str[stringcounter];
                stringcounter++;
            }
            Id = stoi(tempstr);
            stringcounter++;
            tempstr = "";
            while (str[stringcounter] != ',') {
                tempstr += str[stringcounter];
                stringcounter++;
            }
            Year = stoi(tempstr);
            stringcounter++;
            if (str[stringcounter] == '"') {
                stringcounter++; // cause of " character
                tempstr = "";
                while (str[stringcounter] != '"') {
                    tempstr += str[stringcounter];
                    stringcounter++;
                }
                stringcounter++;
            }
            else {
                tempstr = "";
                while (str[stringcounter] != ',') {
                    tempstr += str[stringcounter];
                    stringcounter++;
                }
            }
            CauseName113 = tempstr;
            stringcounter++;
            tempstr = "";
            while (str[stringcounter] != ',') {
                tempstr += str[stringcounter];
                stringcounter++;
            }
            CauseName = tempstr;
            stringcounter++;
            tempstr = "";
            while (str[stringcounter] != ',') {
                tempstr += str[stringcounter];
                stringcounter++;
            }
            State = tempstr;

            stringcounter++;
            tempstr = "";
            while (str[stringcounter] != ',') {
                tempstr += str[stringcounter];
                stringcounter++;
            }
            Deaths = stoi(tempstr);
            stringcounter++;
            tempstr = "";
            while (str[stringcounter] != '\n' && str[stringcounter] != '\0') {
                tempstr += str[stringcounter];
                stringcounter++;
            }
            stringcounter++;
            AadRate = stof(tempstr); // ONE ROW HAS BEEN READ

        }


    }


    template <class T>
    void addData(T*& toInsert)
    {
        path = toInsert->path;
        string str;
        int stringcounter = 0;
        string tempstr;
        ifstream myfile;
        line = toInsert->line;

        myfile.open(path);

        for (int i = 0; i < toInsert->line + 1; i++) // +1 to skip 1st line
        {
            str = "";
            getline(myfile, str); // reading specific line
        }

        if (str != "")
        {

            tempstr = "";
            while (str[stringcounter] != ',') {
                tempstr += str[stringcounter];
                stringcounter++;
            }
            Id = stoi(tempstr);
            stringcounter++;
            tempstr = "";
            while (str[stringcounter] != ',') {
                tempstr += str[stringcounter];
                stringcounter++;
            }
            Year = stoi(tempstr);
            stringcounter++;
            if (str[stringcounter] == '"') {
                stringcounter++; // cause of " character
                tempstr = "";
                while (str[stringcounter] != '"') {
                    tempstr += str[stringcounter];
                    stringcounter++;
                }
                stringcounter++;
            }
            else {
                tempstr = "";
                while (str[stringcounter] != ',') {
                    tempstr += str[stringcounter];
                    stringcounter++;
                }
            }
            CauseName113 = tempstr;
            stringcounter++;
            tempstr = "";
            while (str[stringcounter] != ',') {
                tempstr += str[stringcounter];
                stringcounter++;
            }
            CauseName = tempstr;
            stringcounter++;
            tempstr = "";
            while (str[stringcounter] != ',') {
                tempstr += str[stringcounter];
                stringcounter++;
            }
            State = tempstr;

            stringcounter++;
            tempstr = "";
            while (str[stringcounter] != ',') {
                tempstr += str[stringcounter];
                stringcounter++;
            }
            Deaths = stoi(tempstr);
            stringcounter++;
            tempstr = "";
            while (str[stringcounter] != '\n' && str[stringcounter] != '\0') {
                tempstr += str[stringcounter];
                stringcounter++;
            }
            stringcounter++;
            AadRate = stof(tempstr); // ONE ROW HAS BEEN READ

        }
    }

    bool isEmpty()
    {
        if (Id == 0 && Year == 0 && Deaths == 0 && AadRate == 0 && CauseName113 == "Empty" && CauseName == "Empty" && State == "Empty")
            return true;
        else
            return false;
    }


    void Display() {
        if (!isEmpty())
        {

            cout << "********************************************" << endl;
            cout << "* ID = " << Id << endl;
            cout << "* Year = " << Year << endl;
            cout << "* CauseName113 = " << CauseName113 << endl;
            cout << "* CauseName = " << CauseName << endl;
            cout << "* State = " << State << endl;
            cout << "* Deaths = " << Deaths << endl;
            cout << "* AadRate = " << AadRate << endl;
            cout << "********************************************" << endl << endl;
        }
        else
            cout << "\n* Key Does not exist" << endl;
    }
};

template <class T>
avlNode_ID<T>* getNode(string path) {
    ifstream myfile(path);
    avlNode_ID<T>* temp = new avlNode_ID<T>;
    string str, temp_str;

    if (myfile)
    {
        str = "";
        getline(myfile, str);
        temp->ID = stoi(str);
        getline(myfile, str);
        temp->line = stoi(str);
        getline(myfile, str);
        temp->path = str;

        getline(myfile, str);
        temp->left = str;

        getline(myfile, str);
        temp->right = str;

        getline(myfile, str, '\0');
        int i = 0;
        /* int i = 0;
         getline(myfile, str);

         temp_str = "";
         while (str[i] != '%')
             temp_str += str[i++];

         temp->key->Id = stoi(temp_str);
         i++;

         temp_str = "";
         while (str[i] != '%')
             temp_str += str[i++];

         temp->key->Year = stoi(temp_str);
         i++;

         temp_str = "";
         while (str[i] != '%')
             temp_str += str[i++];

         temp->key->Deaths = stoi(temp_str);
         i++;

         temp_str = "";
         while (str[i] != '%')
             temp_str += str[i++];

         temp->key->CauseName113 = temp_str;
         i++;

         temp_str = "";
         while (str[i] != '%')
             temp_str += str[i++];

         temp->key->CauseName = temp_str;
         i++;

         temp_str = "";
         while (str[i] != '%')
             temp_str += str[i++];

         temp->key->State = temp_str;
         i++;

         temp_str = "";
         while (str[i] != '%')
             temp_str += str[i++];

         temp->key->AadRate = stof(temp_str);
         i++;

         temp_str = "";
         while (str[i] != '%')
             temp_str += str[i++];

         temp->left = temp_str;
         i++;

         temp_str = "";
         while (str[i] != '%')
             temp_str += str[i++];

         temp->right = temp_str;
         i++;*/


        while (str[i] != '\0')
        {
            temp_str = "";

            while (str[i] != '%' && str[i] != '\n')
            {
                temp_str += str[i];
                i++;
            }

            temp->list.enQueue(temp_str);
            i++;
        }

        myfile.close();
    }
    return temp;
}

template <>
avlNode_ID<string>* getNode(string path) {
    ifstream myfile(path);
    avlNode_ID<string>* temp = new avlNode_ID<string>;
    string str, temp_str;

    if (myfile)
    {
        str = "";
        getline(myfile, str);
        temp->ID = str;
        getline(myfile, str);
        temp->line = stoi(str);
        getline(myfile, str);
        temp->path = str;

        getline(myfile, str);
        temp->left = str;

        getline(myfile, str);
        temp->right = str;

        getline(myfile, str, '\0');
        int i = 0;

        while (str[i] != '\0')
        {
            temp_str = "";

            while (str[i] != '%' && str[i] != '\n')
            {
                temp_str += str[i];
                i++;
            }

            temp->list.enQueue(temp_str);
            i++;
        }

        myfile.close();
    }
    return temp;
}

template <>
avlNode_ID<float>* getNode(string path) {
    ifstream myfile(path);
    avlNode_ID<float>* temp = new avlNode_ID<float>;
    string str, temp_str;

    if (myfile)
    {
        str = "";
        getline(myfile, str);
        temp->ID = stof(str);
        getline(myfile, str);
        temp->line = stoi(str);
        getline(myfile, str);
        temp->path = str;

        getline(myfile, str);
        temp->left = str;

        getline(myfile, str);
        temp->right = str;

        getline(myfile, str, '\0');
        int i = 0;

        while (str[i] != '\0')
        {
            temp_str = "";

            while (str[i] != '%' && str[i] != '\n')
            {
                temp_str += str[i];
                i++;
            }

            temp->list.enQueue(temp_str);
            i++;
        }

        myfile.close();
    }
    return temp;
}

template <class T>
void setNode(string path, avlNode_ID<T>*& tempNode)
{
    ofstream myfile(path);

    myfile << tempNode->ID << "\n";
    myfile << tempNode->line << "\n";
    myfile << tempNode->path << "\n";

    myfile << tempNode->left << "\n";
    myfile << tempNode->right << "\n";

    string str;
    int c = 0;

    while (!tempNode->list.isEmpty())
    {
        str += tempNode->list.Front()->data;
        c++;
        if (c != 2)
            str += "%";
        else
        {
            str += "\n";
            c = 0;
        }
        tempNode->list.deQueue();
    }

    myfile << str;

    myfile.close();
}

void MakePathID(string& path, string type, int mycount) {
    path = "";
    path = "AVLTree/AVLTree";
    path += type;
    path += "/node";
    path += to_string(mycount);
    path += ".txt";

}

string MakeRootPath(string type) {
    string path;

    path = "";
    path = "AVLTree/Root";
    path += type;
    path += ".txt";
    return path;
}

template <class T>
class avl_tree {
public:
    avlNode_ID<T>* root;
    int nodeCounter;
    string type;
    avl_tree(string t = "")
    {
        root = NULL;
        type = t;
        nodeCounter = 0;
    }

    int height(string);
    int difference(string);
    string rr_rotat(string);
    string ll_rotat(string);
    string lr_rotat(string);
    string rl_rotat(string);
    string balance(string, bool&);

    avlNode_ID<T>* insert(avlNode_ID<T>*, T, int, string);
    void Delete(avlNode_ID<T>*, T id);
    string search(avlNode_ID<T>*, T id, int);
    void update(avlNode_ID<T>*, T id);

    void setType(string s)
    {
        type = s;
    }

    /* avlNode_ID* insert_Year(avlNode_ID*, Data);
     void Delete_Year(avlNode_ID*, int year);
     string search_Year(avlNode_ID*, int year, int);
     void update_Year(avlNode_ID*, int year);*/

    string getMax(string);
};

template <class T>
int avl_tree<T>::height(string t) {
    int h = 0;
    avlNode_ID<T>* temp = getNode<T>(t);
    int left_h = 0;
    int right_h = 0;
    bool flag = false;

    if (temp->left != "NULL")
    {
        left_h = height(temp->left);
        flag = true;
    }

    if (temp->right != "NULL")
    {
        right_h = height(temp->right);
        flag = true;
    }

    if (!temp->isEmpty())
    {
        int max_h = max(left_h, right_h);
        h = max_h + 1;
    }

    return h;
}

template <class T>
int avl_tree<T>::difference(string t) {
    avlNode_ID<T>* temp = getNode<T>(t);

    int l_height = height(temp->left);
    int r_height = height(temp->right);
    int b_factor = l_height - r_height;
    return b_factor;
}

template <class T>
string avl_tree<T>::rr_rotat(string parent) {
    string t1;
    avlNode_ID<T>* t2 = getNode<T>(parent);
    t1 = t2->right;
    avlNode_ID<T>* t3 = getNode<T>(t1);
    t2->right = t3->left;
    t3->left = parent;
    setNode(parent, t2);
    setNode(t1, t3);
    //cout << "Right-Right Rotation";
    return t1;
}

template <class T>
string avl_tree<T>::ll_rotat(string parent)
{
    string t1;
    avlNode_ID<T>* t2 = getNode<T>(parent);
    t1 = t2->left;
    avlNode_ID<T>* t3 = getNode<T>(t1);

    t2->left = t3->right;
    t3->right = parent;

    setNode(parent, t2);
    setNode(t1, t3);
    //cout << "Left-Left Rotation";
    return t1;
}

template <class T>
string avl_tree<T>::lr_rotat(string parent) {
    string t1;
    avlNode_ID<T>* t2 = getNode<T>(parent);
    t1 = t2->left;
    t2->left = rr_rotat(t1);
    //cout << "Left-Right Rotation";
    setNode(parent, t2);
    return ll_rotat(parent);
}

template <class T>
string avl_tree<T>::rl_rotat(string parent) {
    string t1;
    avlNode_ID<T>* t2 = getNode<T>(parent);
    t1 = t2->right;
    t2->right = ll_rotat(t1);
    //cout << "Right-Left Rotation";
    setNode(parent, t2);
    return rr_rotat(parent);
}

template <class T>
string avl_tree<T>::balance(string t, bool& opposite)
{
    int bal_factor = difference(t);
    avlNode_ID<T>* temp = getNode<T>(t);
    if (bal_factor > 1)
    {
        if (difference(temp->left) > 0)
            t = ll_rotat(t);
        else
        {
            t = lr_rotat(t);
            opposite = true;
        }
    }
    else if (bal_factor < -1)
    {
        if (difference(temp->right) > 0)
        {
            t = rl_rotat(t);
            opposite = true;
        }
        else
            t = rr_rotat(t);

    }
    return t;
}

template <class T>
string avl_tree<T>::getMax(string path)
{
    avlNode_ID<T>* temp = getNode<T>(path);
    mStack<string> stk;
    string str;

    stk.push(path);

    while (temp->left != "NULL")
    {
        stk.push(temp->left);
        temp = getNode<T>(temp->left);
    }
    if (!stk.isEmpty() && stk.top() != path)
    {
        str = stk.top();
        stk.pop();
        temp = getNode<T>(stk.top());
        temp->left = "NULL";
        setNode(stk.top(), temp);
    }

    return str;
}

int str_val(string a)
{
    int sum = 0;
    for (int i = 0; a[i] != '\0'; i++)
    {
        sum += a[i] * (i + 1);
    }
    //cout << sum << endl;
    return sum;
}

//******************************* Template Indexing ********************************

template <class T>
avlNode_ID<T>* avl_tree<T>::insert(avlNode_ID<T>* r, T data, int line, string path)
{
    if (data == 2012)
        data = data + 0;

    if (r == NULL)
    {
        r = new avlNode_ID<T>;
        r->addData(data, line, path);
        r->left = "NULL";
        r->right = "NULL";
        setNode(MakeRootPath(type), r);
        int h = height(MakeRootPath(type));
        return r;
    }
    else
    {
        string str_temp = MakeRootPath(type);
        string str_temp2;
        avlNode_ID<T>* temp;
        mStack<string> stk;
        mStack<string> h_stk;
        string dir;
        string check;
        bool flag1 = false;
        bool flag2 = false;
        stk.push(str_temp);
        h_stk.push(str_temp);

        while (!stk.isEmpty())
        {
            str_temp = stk.top();
            stk.pop();
            temp = getNode<T>(str_temp);

            if (data < temp->ID)
            {
                if (temp->left != "NULL")
                {
                    stk.push(temp->left);
                    h_stk.push("left");
                    h_stk.push(temp->left);
                }
                else
                {
                    MakePathID(temp->left, type, nodeCounter++);
                    setNode(str_temp, temp);

                    str_temp2 = temp->left;
                    temp->left = "NULL";
                    temp->right = "NULL";
                    temp->addData(data, line, path);
                    setNode(str_temp2, temp);
                    h_stk.push("left");
                    h_stk.push(str_temp2);


                    while (!h_stk.isEmpty())
                    {
                        flag2 = false;
                        flag1 = false;
                        check = h_stk.top();
                        str_temp = balance(h_stk.top(), flag2);
                        if (str_temp != h_stk.top())
                            flag1 = true;
                        h_stk.pop();

                        temp = getNode<T>(str_temp);
                        temp = getNode<T>(temp->left);
                        temp = getNode<T>(temp->right);


                        if (flag2 && temp->ID != data)
                            goto right_ins;

                    left_ins:
                        if (flag1)
                        {
                            if (!h_stk.isEmpty() && h_stk.top() == "right")
                            {
                                //h_stk.pop();
                                goto right_ins;
                            }

                            if (h_stk.isEmpty())
                            {


                                temp = getNode<T>(MakeRootPath(type));
                                r = getNode<T>(str_temp);

                                if (r->right == MakeRootPath(type))
                                    goto right_ins;

                                r->left = str_temp;
                                setNode(MakeRootPath(type), r);
                                setNode(str_temp, temp);
                            }
                            else
                            {
                                h_stk.pop();
                                r = getNode<T>(h_stk.top());
                                r->left = str_temp;
                                setNode<T>(h_stk.top(), r);
                            }
                        }
                        else
                        {
                            if (!h_stk.isEmpty())
                                dir = h_stk.top();
                            h_stk.pop();
                        }
                    }

                    //str_temp = balance(str_temp);
                }
            }
            else if (data > temp->ID)
            {
                if (temp->right != "NULL")
                {
                    stk.push(temp->right);
                    h_stk.push("right");
                    h_stk.push(temp->right);
                }
                else
                {
                    MakePathID(temp->right, type, nodeCounter++);
                    setNode(str_temp, temp);

                    str_temp2 = temp->right;
                    temp->left = "NULL";
                    temp->right = "NULL";
                    temp->addData(data, line, path);
                    setNode(str_temp2, temp);
                    h_stk.push("right");
                    h_stk.push(str_temp2);

                    while (!h_stk.isEmpty())
                    {
                        flag1 = false;
                        flag2 = false;
                        check = h_stk.top();
                        str_temp = balance(h_stk.top(), flag2);
                        if (str_temp != h_stk.top())
                            flag1 = true;

                        h_stk.pop();

                        temp = getNode<T>(str_temp);
                        temp = getNode<T>(temp->right);
                        temp = getNode<T>(temp->left);


                        if (flag2 && temp->ID != data)
                            goto left_ins;

                    right_ins:
                        if (flag1)
                        {
                            if (!h_stk.isEmpty() && h_stk.top() == "left")
                            {
                                //h_stk.pop();
                                goto left_ins;
                            }
                            if (h_stk.isEmpty())
                            {
                                temp = getNode<T>(MakeRootPath(type));
                                r = getNode<T>(str_temp);

                                if (r->left == MakeRootPath(type))
                                    goto left_ins;

                                r->right = str_temp;
                                setNode(MakeRootPath(type), r);
                                setNode(str_temp, temp);
                            }
                            else
                            {
                                dir = h_stk.top();
                                h_stk.pop();
                                r = getNode<T>(h_stk.top());
                                r->right = str_temp;
                                setNode(h_stk.top(), r);
                            }
                        }
                        else
                        {
                            if (!h_stk.isEmpty())
                                dir = h_stk.top();
                            h_stk.pop();
                        }
                    }

                    // str_temp = balance(str_temp);
                     //return r;

                }
            }
            else
            {
                // MakePathID(str_temp2,"ID", nodeCounter++);
                temp->list.enQueue(to_string(line));
                temp->list.enQueue(path);
                setNode(str_temp, temp);

                /*temp->left = "NULL";
                temp->right = "NULL";
                temp->addData(data,line,path);
                setNode(str_temp2, temp);*/

            }
        }

        r = getNode<T>(str_temp);

        return r;
    }
}

template <class T>
void avl_tree<T>::Delete(avlNode_ID<T>* r, T id)
{
    if (r == NULL)
    {
        return;
    }
    else
    {
        string str_temp = MakeRootPath(type);
        string str_temp2;
        string dir;
        avlNode_ID<T>* temp;
        mStack<string> stk;
        mStack<string> h_stk;
        bool flag1 = false;
        bool flag2 = false;
        bool flag3 = false;
        stk.push(str_temp);
        h_stk.push(str_temp);
        avlNode_ID<T>* toDelete;

        while (!stk.isEmpty())
        {
            str_temp = stk.top();
            stk.pop();
            temp = getNode<T>(str_temp);

            if (id < temp->ID)
            {
                if (temp->left != "NULL")
                {
                    stk.push(temp->left);
                    h_stk.push("left");
                    h_stk.push(temp->left);
                }
            }
            else if (id > temp->ID)
            {
                if (temp->right != "NULL")
                {
                    stk.push(temp->right);
                    h_stk.push("right");
                    h_stk.push(temp->right);
                }
            }
            else
            {
                toDelete = getNode<T>(str_temp);

                if (temp->left == "NULL" && temp->right == "NULL")
                {
                    remove(str_temp.c_str());
                    h_stk.pop();
                    dir = h_stk.top();

                    if (dir == "left")
                    {
                        h_stk.pop();
                        str_temp = h_stk.top();
                        temp = getNode<T>(str_temp);
                        temp->left = "NULL";
                        setNode(str_temp, temp);
                    }
                    else if (dir == "right")
                    {
                        h_stk.pop();
                        str_temp = h_stk.top();
                        temp = getNode<T>(str_temp);
                        temp->right = "NULL";
                        setNode(str_temp, temp);
                    }
                }
                else if (temp->left != "NULL" && temp->right != "NULL")
                {
                    avlNode_ID<T>* temp2;
                    temp = getNode<T>(str_temp);
                    remove(str_temp.c_str());
                    str_temp2 = getMax(temp->right);

                    if (str_temp2 == temp->right)
                        temp->right = "NULL";

                    temp2 = getNode<T>(str_temp2);
                    temp2->left = temp->left;
                    temp2->right = temp->right;
                    setNode(str_temp2, temp2);

                    h_stk.pop();
                    dir = h_stk.top();

                    if (dir == "left")
                    {
                        h_stk.pop();
                        str_temp = h_stk.top();
                        temp = getNode<T>(str_temp);
                        temp->left = str_temp2;
                        setNode(str_temp, temp);
                    }
                    else if (dir == "right")
                    {
                        h_stk.pop();
                        str_temp = h_stk.top();
                        temp = getNode<T>(str_temp);
                        temp->right = str_temp2;
                        setNode(str_temp, temp);
                    }


                }
                else
                {
                    if (temp->left != "NULL")
                        str_temp2 = temp->left;
                    else
                        str_temp2 = temp->right;

                    remove(str_temp.c_str());
                    h_stk.pop();
                    dir = h_stk.top();

                    if (dir == "left")
                    {
                        h_stk.pop();
                        str_temp = h_stk.top();
                        temp = getNode<T>(str_temp);
                        temp->left = str_temp2;
                        setNode(str_temp, temp);
                    }
                    else if (dir == "right")
                    {
                        h_stk.pop();
                        str_temp = h_stk.top();
                        temp = getNode<T>(str_temp);
                        temp->right = str_temp2;
                        setNode(str_temp, temp);
                    }
                }


                if (dir == "right")
                {
                    while (!h_stk.isEmpty())
                    {
                        flag2 = false;
                        flag1 = false;
                        str_temp = balance(h_stk.top(), flag2);
                        if (str_temp != h_stk.top())
                            flag1 = true;
                        h_stk.pop();

                        if (flag2)
                            goto right_ins;
                    left_ins:
                        if (flag1)
                        {
                            if (!h_stk.isEmpty() && h_stk.top() == "right")
                            {
                                //h_stk.pop();
                                goto right_ins;
                            }
                            if (h_stk.isEmpty())
                            {
                                temp = getNode<T>(MakeRootPath(type));
                                r = getNode<T>(str_temp);
                                r->right = str_temp;
                                setNode(MakeRootPath(type), r);
                                setNode(str_temp, temp);
                            }
                            else
                            {
                                h_stk.pop();
                                r = getNode<T>(h_stk.top());
                                r->left = str_temp;
                                setNode(h_stk.top(), r);
                            }
                        }
                        else
                            h_stk.pop();
                    }
                }
                else if (dir == "left")
                {
                    while (!h_stk.isEmpty())
                    {
                        flag1 = false;
                        flag2 = false;
                        str_temp = balance(h_stk.top(), flag2);
                        if (str_temp != h_stk.top())
                            flag1 = true;
                        h_stk.pop();

                        if (flag2)
                            goto left_ins;
                    right_ins:
                        if (flag1)
                        {
                            if (!h_stk.isEmpty() && h_stk.top() == "left")
                            {
                                //h_stk.pop();
                                goto left_ins;
                            }
                            if (h_stk.isEmpty())
                            {
                                temp = getNode<T>(MakeRootPath(type));
                                r = getNode<T>(str_temp);
                                r->left = str_temp;
                                setNode(MakeRootPath(type), r);
                                setNode(str_temp, temp);
                            }
                            else
                            {
                                h_stk.pop();
                                r = getNode<T>(h_stk.top());
                                r->right = str_temp;
                                setNode(h_stk.top(), r);
                            }
                        }
                        else
                            h_stk.pop();
                    }
                }

                aData key;
                key.addData(toDelete);
                while (!toDelete->list.isEmpty())
                {
                    key.line = stoi(toDelete->list.Front()->data);
                    toDelete->list.deQueue();
                    key.path = toDelete->list.Front()->data;
                    toDelete->list.deQueue();
                    key.Delete();
                }

                key.addData(toDelete);
                key.Delete();

            }
        }
    }

}

template <class T>
string avl_tree<T>::search(avlNode_ID<T>* r, T id, int choice) // if choice 0 -> result will not print; only return path
{
    if (r == NULL)
    {
        return "";
    }
    else
    {
        string str_temp = MakeRootPath(type);
        avlNode_ID<T>* temp;
        mStack<string> stk;
        stk.push(str_temp);

        while (!stk.isEmpty())
        {
            str_temp = stk.top();
            stk.pop();
            temp = getNode<T>(str_temp);

            if (id < temp->ID)
            {
                if (temp->left != "NULL")
                {
                    stk.push(temp->left);
                }
            }
            else if (id > temp->ID)
            {
                if (temp->right != "NULL")
                {
                    stk.push(temp->right);
                }
            }
            else
            {
                if (choice == 1)
                {
                    avlNode_ID<T>* temp_node;
                    temp_node = getNode<T>(str_temp);
                    aData key;
                    key.addData(temp_node);
                    key.Display();

                    while (!temp_node->list.isEmpty())
                    {
                        temp_node->line = stoi(temp_node->list.Front()->data);
                        temp_node->list.deQueue();
                        temp_node->path = temp_node->list.Front()->data;
                        temp_node->list.deQueue();

                        key.addData(temp_node);
                        key.Display();

                    }
                }

                return str_temp;
            }
        }

        cout << "\n * Key Does not Exist";

        return "";
    }
}

template <class T>
void avl_tree<T>::update(avlNode_ID<T>* r, T id)
{
    int num;

    int Id = 0; int Year = 0; int Deaths = 0;
    string CauseName113{}; string CauseName{}; string State{};
    float AadRate = 0.0;

    int Id1 = 0; int Year1 = 0; int Deaths1 = 0;
    string CauseName1131{}; string CauseName1{}; string State1{};
    float AadRate1 = 0.0;

    string path = search(r, id, 0);

    avlNode_ID<T>* temp;
    temp = getNode<T>(path);

    if (!temp->isEmpty())
    {
        cout << "1. Year\n2. Deaths\n3. CauseName113\n4. CauseName \n5. State \n6. Death Rate \n";
        cout << "\nPress Number to update that Field: ";
        cin >> num;
        cout << "\nEnter Old value\nEnter 0 for all values: ";
        if (num == 1)
        {
            cin >> Year1;

            cout << "\nEnter Years: ";
            cin >> Year;
        }
        else if (num == 2)
        {
            cin >> Deaths1;

            cout << "\nEnter Deaths: ";
            cin >> Deaths;
        }
        else if (num == 3)
        {
            cin >> CauseName1131;

            cout << "\nEnter Cause Name 113: ";
            cin >> CauseName113;
        }
        else if (num == 4)
        {
            cin >> CauseName1;

            cout << "\nEnter Cause Name: ";
            cin >> CauseName;
        }
        else if (num == 5)
        {
            cin >> State1;

            cout << "\nEnter State: ";
            cin >> State;
        }
        else if (num == 6)
        {
            cin >> AadRate1;

            cout << "\nEnter Aad Rate: ";
            cin >> AadRate;
        }

        temp = getNode<T>(path);

        aData key;

        while (!temp->list.isEmpty())
        {
            int l = stoi(temp->list.Front()->data);
            temp->list.deQueue();
            string p = temp->list.Front()->data;
            temp->list.deQueue();

            key.getFromPath(l, p);

            if (num == 1)
            {
                if (Year1 == key.Year)
                    key.update(num, Year, Deaths, CauseName113, CauseName, State, AadRate);
            }
            else if (num == 2)
            {
                if (Deaths1 == key.Deaths)
                    key.update(num, Year, Deaths, CauseName113, CauseName, State, AadRate);
            }
            else if (num == 3)
            {
                if (CauseName1131 == key.CauseName113)
                    key.update(num, Year, Deaths, CauseName113, CauseName, State, AadRate);
            }
            else if (num == 4)
            {
                if (CauseName1 == key.CauseName)
                    key.update(num, Year, Deaths, CauseName113, CauseName, State, AadRate);
            }
            else if (num == 5)
            {
                if (State1 == key.State)
                    key.update(num, Year, Deaths, CauseName113, CauseName, State, AadRate);
            }
            else if (num == 6)
            {
                if (AadRate1 == key.AadRate)
                    key.update(num, Year, Deaths, CauseName113, CauseName, State, AadRate);
            }

        }

        /* if (num == 1)
         {
             if (Year1 == key.Year || Years1 == 0)
                 key.update(num, Year, Deaths, CauseName113, CauseName, State, AadRate);
         }
         else if (num == 2)
         {
             if (Deaths1 == key.Deaths || Deaths1 == 0)
                 key.update(num, Year, Deaths, CauseName113, CauseName, State, AadRate);
         }
         else if (num == 3)
         {
             if (CauseName1131 == key.CauseName113 || CauseName1131 == 0)
                 key.update(num, Year, Deaths, CauseName113, CauseName, State, AadRate);
         }
         else if (num == 4)
         {
             if (CauseName1 == key.CauseName || CausName1 == 0)
                 key.update(num, Year, Deaths, CauseName113, CauseName, State, AadRate);
         }
         else if (num == 5)
         {
             if (State1 == key.State || State1 == 0)
                 key.update(num, Year, Deaths, CauseName113, CauseName, State, AadRate);
         }
         else if (num == 6)
         {
             if (AadRate1 == key.AadRate || AadRate1 == 0)
                 key.update(num, Year, Deaths, CauseName113, CauseName, State, AadRate);
         }*/


        key.addData(temp);

        if (num == 1)
        {
            if (Year1 == key.Year)
                key.update(num, Year, Deaths, CauseName113, CauseName, State, AadRate);
        }
        else if (num == 2)
        {
            if (Deaths1 == key.Deaths)
                key.update(num, Year, Deaths, CauseName113, CauseName, State, AadRate);
        }
        else if (num == 3)
        {
            if (CauseName1131 == key.CauseName113)
                key.update(num, Year, Deaths, CauseName113, CauseName, State, AadRate);
        }
        else if (num == 4)
        {
            if (CauseName1 == key.CauseName)
                key.update(num, Year, Deaths, CauseName113, CauseName, State, AadRate);
        }
        else if (num == 5)
        {
            if (State1 == key.State)
                key.update(num, Year, Deaths, CauseName113, CauseName, State, AadRate);
        }
        else if (num == 6)
        {
            if (AadRate1 == key.AadRate)
                key.update(num, Year, Deaths, CauseName113, CauseName, State, AadRate);
        }

    }
    else
        cout << "\nID Does not exist";

}

//********************************************************************************

//******************************* String Indexing **********************************


template <>
avlNode_ID<string>* avl_tree<string>::insert(avlNode_ID<string>* r, string data, int line, string path)
{
    if (r == NULL)
    {
        r = new avlNode_ID<string>;
        r->addData(data, line, path);
        r->left = "NULL";
        r->right = "NULL";
        setNode(MakeRootPath(type), r);
        int h = height(MakeRootPath(type));
        return r;
    }
    else
    {
        string str_temp = MakeRootPath(type);
        string str_temp2;
        avlNode_ID<string>* temp;
        mStack<string> stk;
        mStack<string> h_stk;
        string dir;
        string check;
        bool flag1 = false;
        bool flag2 = false;
        stk.push(str_temp);
        h_stk.push(str_temp);

        while (!stk.isEmpty())
        {
            str_temp = stk.top();
            stk.pop();
            temp = getNode<string>(str_temp);

            if (str_val(data) < str_val(temp->ID))
            {
                if (temp->left != "NULL")
                {
                    stk.push(temp->left);
                    h_stk.push("left");
                    h_stk.push(temp->left);
                }
                else
                {
                    MakePathID(temp->left, type, nodeCounter++);
                    setNode(str_temp, temp);

                    str_temp2 = temp->left;
                    temp->left = "NULL";
                    temp->right = "NULL";
                    temp->addData(data, line, path);
                    setNode(str_temp2, temp);
                    h_stk.push("left");
                    h_stk.push(str_temp2);


                    while (!h_stk.isEmpty())
                    {
                        flag2 = false;
                        flag1 = false;
                        check = h_stk.top();

                        str_temp = balance(h_stk.top(), flag2);
                        if (str_temp != h_stk.top())
                            flag1 = true;
                        h_stk.pop();

                        temp = getNode<string>(str_temp);
                        temp = getNode<string>(temp->left);
                        temp = getNode<string>(temp->right);


                        if (flag2 && temp->ID != data)
                            goto right_ins;

                    left_ins:
                        if (flag1)
                        {
                            if (!h_stk.isEmpty() && h_stk.top() == "right")
                            {
                                //h_stk.pop();
                                goto right_ins;
                            }
                            if (h_stk.isEmpty())
                            {
                                /*if (check == MakeRootPath(type))
                                {
                                    check = "";
                                    goto right_ins;
                                }*/


                                temp = getNode<string>(MakeRootPath(type));
                                r = getNode<string>(str_temp);

                                if (r->right == MakeRootPath(type))
                                    goto right_ins;

                                r->left = str_temp;
                                setNode(MakeRootPath(type), r);
                                setNode(str_temp, temp);
                            }
                            else
                            {
                                h_stk.pop();
                                r = getNode<string>(h_stk.top());
                                r->left = str_temp;
                                setNode<string>(h_stk.top(), r);
                            }
                        }
                        else
                        {
                            if (!h_stk.isEmpty())
                                dir = h_stk.top();
                            h_stk.pop();
                        }


                        /*if (flag2)
                        {
                            flag2 = false;
                            flag1 = false;
                            goto right_ins;
                        }*/
                    }

                    //str_temp = balance(str_temp);
                }
            }
            else if (str_val(data) > str_val(temp->ID))
            {
                if (temp->right != "NULL")
                {
                    stk.push(temp->right);
                    h_stk.push("right");
                    h_stk.push(temp->right);
                }
                else
                {
                    MakePathID(temp->right, type, nodeCounter++);
                    setNode(str_temp, temp);

                    str_temp2 = temp->right;
                    temp->left = "NULL";
                    temp->right = "NULL";
                    temp->addData(data, line, path);
                    setNode(str_temp2, temp);
                    h_stk.push("right");
                    h_stk.push(str_temp2);

                    while (!h_stk.isEmpty())
                    {
                        flag1 = false;
                        flag2 = false;
                        check = h_stk.top();
                        str_temp = balance(h_stk.top(), flag2);
                        if (str_temp != h_stk.top())
                            flag1 = true;
                        h_stk.pop();

                        temp = getNode<string>(str_temp);
                        temp = getNode<string>(temp->right);
                        temp = getNode<string>(temp->left);


                        if (flag2 && temp->ID != data)
                            goto left_ins;

                    right_ins:
                        if (flag1)
                        {
                            if (!h_stk.isEmpty() && h_stk.top() == "left")
                            {
                                //h_stk.pop();
                                goto left_ins;
                            }
                            if (h_stk.isEmpty())
                            {

                                temp = getNode<string>(MakeRootPath(type));
                                r = getNode<string>(str_temp);

                                if (r->left == MakeRootPath(type))
                                    goto left_ins;

                                r->right = str_temp;
                                setNode(MakeRootPath(type), r);
                                setNode(str_temp, temp);
                            }
                            else
                            {
                                h_stk.pop();
                                r = getNode<string>(h_stk.top());
                                r->right = str_temp;
                                setNode(h_stk.top(), r);
                            }
                        }
                        else
                        {
                            if (!h_stk.isEmpty())
                                dir = h_stk.top();
                            h_stk.pop();
                        }

                        /*if (flag2)
                        {
                            flag2 = false;
                            flag1 = false;
                            goto left_ins;
                        }*/
                    }

                    // str_temp = balance(str_temp);
                     //return r;
                }
            }
            else
            {
                //MakePathID(str_temp2, "ID", nodeCounter++);
                temp->list.enQueue(to_string(line));
                temp->list.enQueue(path);
                setNode(str_temp, temp);

                /*temp->left = "NULL";
                temp->right = "NULL";
                temp->addData(data, line, path);
                setNode(str_temp2, temp);*/

            }
        }

        r = getNode<string>(str_temp);

        return r;
    }
}

template <>
string avl_tree<string>::search(avlNode_ID<string>* r, string id, int choice) // if choice 0 -> result will not print; only return path
{
    if (r == NULL)
    {
        return "";
    }
    else
    {
        string str_temp = MakeRootPath(type);
        avlNode_ID<string>* temp;
        mStack<string> stk;
        stk.push(str_temp);

        while (!stk.isEmpty())
        {
            str_temp = stk.top();
            stk.pop();
            temp = getNode<string>(str_temp);

            if (str_val(id) < str_val(temp->ID))
            {
                if (temp->left != "NULL")
                {
                    stk.push(temp->left);
                }
            }
            else if (str_val(id) > str_val(temp->ID))
            {
                if (temp->right != "NULL")
                {
                    stk.push(temp->right);
                }
            }
            else
            {
                if (choice == 1)
                {
                    avlNode_ID<string>* temp_node;
                    temp_node = getNode<string>(str_temp);
                    aData key;
                    key.addData(temp_node);
                    key.Display();

                    while (!temp_node->list.isEmpty())
                    {
                        temp_node->line = stoi(temp_node->list.Front()->data);
                        temp_node->list.deQueue();
                        temp_node->path = temp_node->list.Front()->data;
                        temp_node->list.deQueue();

                        key.addData(temp_node);
                        key.Display();

                    }
                }

                return str_temp;
            }
        }

        cout << "\n * Key Does not Exist";

        return "";
    }
}

template <>
void avl_tree<string>::Delete(avlNode_ID<string>* r, string id)
{
    if (r == NULL)
    {
        return;
    }
    else
    {
        string str_temp = MakeRootPath(type);
        string str_temp2;
        string dir;
        avlNode_ID<string>* temp;
        mStack<string> stk;
        mStack<string> h_stk;
        bool flag1 = false;
        bool flag2 = false;
        bool flag3 = false;
        stk.push(str_temp);
        h_stk.push(str_temp);
        avlNode_ID<string>* toDelete;

        while (!stk.isEmpty())
        {
            str_temp = stk.top();
            stk.pop();
            temp = getNode<string>(str_temp);

            if (id < temp->ID)
            {
                if (temp->left != "NULL")
                {
                    stk.push(temp->left);
                    h_stk.push("left");
                    h_stk.push(temp->left);
                }
            }
            else if (id > temp->ID)
            {
                if (temp->right != "NULL")
                {
                    stk.push(temp->right);
                    h_stk.push("right");
                    h_stk.push(temp->right);
                }
            }
            else
            {
                toDelete = getNode<string>(str_temp);

                if (temp->left == "NULL" && temp->right == "NULL")
                {
                    remove(str_temp.c_str());
                    h_stk.pop();
                    dir = h_stk.top();

                    if (dir == "left")
                    {
                        h_stk.pop();
                        str_temp = h_stk.top();
                        temp = getNode<string>(str_temp);
                        temp->left = "NULL";
                        setNode(str_temp, temp);
                    }
                    else if (dir == "right")
                    {
                        h_stk.pop();
                        str_temp = h_stk.top();
                        temp = getNode<string>(str_temp);
                        temp->right = "NULL";
                        setNode(str_temp, temp);
                    }
                }
                else if (temp->left != "NULL" && temp->right != "NULL")
                {
                    avlNode_ID<string>* temp2;
                    temp = getNode<string>(str_temp);
                    remove(str_temp.c_str());
                    str_temp2 = getMax(temp->right);

                    if (str_temp2 == temp->right)
                        temp->right = "NULL";

                    temp2 = getNode<string>(str_temp2);
                    temp2->left = temp->left;
                    temp2->right = temp->right;
                    setNode(str_temp2, temp2);

                    h_stk.pop();
                    dir = h_stk.top();

                    if (dir == "left")
                    {
                        h_stk.pop();
                        str_temp = h_stk.top();
                        temp = getNode<string>(str_temp);
                        temp->left = str_temp2;
                        setNode(str_temp, temp);
                    }
                    else if (dir == "right")
                    {
                        h_stk.pop();
                        str_temp = h_stk.top();
                        temp = getNode<string>(str_temp);
                        temp->right = str_temp2;
                        setNode(str_temp, temp);
                    }


                }
                else
                {
                    if (temp->left != "NULL")
                        str_temp2 = temp->left;
                    else
                        str_temp2 = temp->right;

                    remove(str_temp.c_str());
                    h_stk.pop();
                    dir = h_stk.top();

                    if (dir == "left")
                    {
                        h_stk.pop();
                        str_temp = h_stk.top();
                        temp = getNode<string>(str_temp);
                        temp->left = str_temp2;
                        setNode(str_temp, temp);
                    }
                    else if (dir == "right")
                    {
                        h_stk.pop();
                        str_temp = h_stk.top();
                        temp = getNode<string>(str_temp);
                        temp->right = str_temp2;
                        setNode(str_temp, temp);
                    }
                }


                if (dir == "right")
                {
                    while (!h_stk.isEmpty())
                    {
                        flag2 = false;
                        flag1 = false;
                        str_temp = balance(h_stk.top(), flag2);
                        if (str_temp != h_stk.top())
                            flag1 = true;
                        h_stk.pop();

                        if (flag2)
                            goto right_ins;
                    left_ins:
                        if (flag1)
                        {
                            if (!h_stk.isEmpty() && h_stk.top() == "right")
                            {
                                //h_stk.pop();
                                goto right_ins;
                            }
                            if (h_stk.isEmpty())
                            {
                                temp = getNode<string>(MakeRootPath(type));
                                r = getNode<string>(str_temp);
                                r->right = str_temp;
                                setNode(MakeRootPath(type), r);
                                setNode(str_temp, temp);
                            }
                            else
                            {
                                h_stk.pop();
                                r = getNode<string>(h_stk.top());
                                r->left = str_temp;
                                setNode(h_stk.top(), r);
                            }
                        }
                        else
                            h_stk.pop();
                    }
                }
                else if (dir == "left")
                {
                    while (!h_stk.isEmpty())
                    {
                        flag1 = false;
                        flag2 = false;
                        str_temp = balance(h_stk.top(), flag2);
                        if (str_temp != h_stk.top())
                            flag1 = true;
                        h_stk.pop();

                        if (flag2)
                            goto left_ins;
                    right_ins:
                        if (flag1)
                        {
                            if (!h_stk.isEmpty() && h_stk.top() == "left")
                            {
                                //h_stk.pop();
                                goto left_ins;
                            }
                            if (h_stk.isEmpty())
                            {
                                temp = getNode<string>(MakeRootPath(type));
                                r = getNode<string>(str_temp);
                                r->left = str_temp;
                                setNode(MakeRootPath(type), r);
                                setNode(str_temp, temp);
                            }
                            else
                            {
                                h_stk.pop();
                                r = getNode<string>(h_stk.top());
                                r->right = str_temp;
                                setNode(h_stk.top(), r);
                            }
                        }
                        else
                            h_stk.pop();
                    }
                }

                aData key;
                key.addData(toDelete);
                while (!toDelete->list.isEmpty())
                {
                    key.line = stoi(toDelete->list.Front()->data);
                    toDelete->list.deQueue();
                    key.path = toDelete->list.Front()->data;
                    toDelete->list.deQueue();
                    key.Delete();
                }

                key.addData(toDelete);
                key.Delete();

            }
        }
    }

}

template <>
void avl_tree<string>::update(avlNode_ID<string>* r, string id)
{
    int num;

    int Id = 0; int Year = 0; int Deaths = 0;
    string CauseName113{}; string CauseName{}; string State{};
    float AadRate = 0.0;

    int Id1 = 0; int Year1 = 0; int Deaths1 = 0;
    string CauseName1131{}; string CauseName1{}; string State1{};
    float AadRate1 = 0.0;

    string path = search(r, id, 0);

    avlNode_ID<string>* temp;
    temp = getNode<string>(path);

    if (!temp->isEmpty())
    {
        cout << "1. Year\n2. Deaths\n3. CauseName113\n4. CauseName \n5. State \n6. Death Rate \n";
        cout << "\nPress Number to update that Field: ";
        cin >> num;
        cout << "\nEnter Old value\nEnter 0 for all values: ";
        if (num == 1)
        {
            cin >> Year1;

            cout << "\nEnter Years: ";
            cin >> Year;
        }
        else if (num == 2)
        {
            cin >> Deaths1;

            cout << "\nEnter Deaths: ";
            cin >> Deaths;
        }
        else if (num == 3)
        {
            cin >> CauseName1131;

            cout << "\nEnter Cause Name 113: ";
            cin >> CauseName113;
        }
        else if (num == 4)
        {
            cin >> CauseName1;

            cout << "\nEnter Cause Name: ";
            cin >> CauseName;
        }
        else if (num == 5)
        {
            cin >> State1;

            cout << "\nEnter State: ";
            cin >> State;
        }
        else if (num == 6)
        {
            cin >> AadRate1;

            cout << "\nEnter Aad Rate: ";
            cin >> AadRate;
        }

        temp = getNode<string>(path);

        aData key;

        while (!temp->list.isEmpty())
        {
            int l = stoi(temp->list.Front()->data);
            temp->list.deQueue();
            string p = temp->list.Front()->data;
            temp->list.deQueue();

            key.getFromPath(l, p);

            if (num == 1)
            {
                if (Year1 == key.Year)
                    key.update(num, Year, Deaths, CauseName113, CauseName, State, AadRate);
            }
            else if (num == 2)
            {
                if (Deaths1 == key.Deaths)
                    key.update(num, Year, Deaths, CauseName113, CauseName, State, AadRate);
            }
            else if (num == 3)
            {
                if (CauseName1131 == key.CauseName113)
                    key.update(num, Year, Deaths, CauseName113, CauseName, State, AadRate);
            }
            else if (num == 4)
            {
                if (CauseName1 == key.CauseName)
                    key.update(num, Year, Deaths, CauseName113, CauseName, State, AadRate);
            }
            else if (num == 5)
            {
                if (State1 == key.State)
                    key.update(num, Year, Deaths, CauseName113, CauseName, State, AadRate);
            }
            else if (num == 6)
            {
                if (AadRate1 == key.AadRate)
                    key.update(num, Year, Deaths, CauseName113, CauseName, State, AadRate);
            }

        }

        key.addData(temp);

        if (num == 1)
        {
            if (Year1 == key.Year)
                key.update(num, Year, Deaths, CauseName113, CauseName, State, AadRate);
        }
        else if (num == 2)
        {
            if (Deaths1 == key.Deaths)
                key.update(num, Year, Deaths, CauseName113, CauseName, State, AadRate);
        }
        else if (num == 3)
        {
            if (CauseName1131 == key.CauseName113)
                key.update(num, Year, Deaths, CauseName113, CauseName, State, AadRate);
        }
        else if (num == 4)
        {
            if (CauseName1 == key.CauseName)
                key.update(num, Year, Deaths, CauseName113, CauseName, State, AadRate);
        }
        else if (num == 5)
        {
            if (State1 == key.State)
                key.update(num, Year, Deaths, CauseName113, CauseName, State, AadRate);
        }
        else if (num == 6)
        {
            if (AadRate1 == key.AadRate)
                key.update(num, Year, Deaths, CauseName113, CauseName, State, AadRate);
        }

    }
    else
        cout << "\nID Does not exist";

}

//update


void AVLtree_maker(int c) {
    string tempPath = "datafiles/NCHS_-_Leading_Causes_of_Death__United_States_1.csv";
    string CSVpaths[10];
    char filenum;
    for (int i = 1; i < 10; i++) {
        filenum = i + '0';
        tempPath[tempPath.length() - 5] = filenum;
        CSVpaths[i - 1] = tempPath;
    }
    tempPath = "datafiles/NCHS_-_Leading_Causes_of_Death__United_States_10.csv";
    CSVpaths[9] = tempPath;
    int count = 0;
    fstream myfile;
    string str, tempstr;
    int stringcounter;
    Data toInsert;

    if (c == 1 || c == 2 || c == 6)
    {
        avl_tree<int> myTree;

        while (count < 1)
        {

            stringcounter = 0;
            str = ""; tempstr = "";
            int lines = 1;

            while (1)
            {
                myfile.open(CSVpaths[count]);

                //for (int i = 0; i < lines + 1; i++) // +1 to skip 1st line
                //{
                //    str = "";
                //    getline(myfile, str); // reading specific line
                //}

                GotoLine(myfile, lines + 1);
                str = "";
                getline(myfile, str);

                if (str != "")
                {
                    stringcounter = 0;
                    tempstr = "";

                    tempstr = "";
                    while (str[stringcounter] != ',') {
                        tempstr += str[stringcounter];
                        stringcounter++;
                    }
                    toInsert.Id = stoi(tempstr);

                    if (c == 1)
                        goto insert;

                    stringcounter++;
                    tempstr = "";
                    while (str[stringcounter] != ',') {
                        tempstr += str[stringcounter];
                        stringcounter++;
                    }
                    toInsert.Year = stoi(tempstr);

                    if (c == 2)
                        goto insert;
                    stringcounter++;
                    if (str[stringcounter] == '"') {
                        stringcounter++; // cause of " character
                        tempstr = "";
                        while (str[stringcounter] != '"') {
                            tempstr += str[stringcounter];
                            stringcounter++;
                        }
                        stringcounter++;
                    }
                    else {
                        tempstr = "";
                        while (str[stringcounter] != ',') {
                            tempstr += str[stringcounter];
                            stringcounter++;
                        }
                    }
                    toInsert.CauseName113 = tempstr;

                    if (c == 3)
                        goto insert;
                    stringcounter++;
                    tempstr = "";
                    while (str[stringcounter] != ',') {
                        tempstr += str[stringcounter];
                        stringcounter++;
                    }
                    toInsert.CauseName = tempstr;

                    if (c == 4)
                        goto insert;
                    stringcounter++;
                    tempstr = "";
                    while (str[stringcounter] != ',') {
                        tempstr += str[stringcounter];
                        stringcounter++;
                    }
                    toInsert.State = tempstr;

                    if (c == 5)
                        goto insert;

                    // cout << "FIFTH Read = " << tempstr << endl;
                    stringcounter++;
                    tempstr = "";
                    while (str[stringcounter] != ',') {
                        tempstr += str[stringcounter];
                        stringcounter++;
                    }
                    toInsert.Deaths = stoi(tempstr);

                    if (c == 6)
                        goto insert;

                    stringcounter++;
                    tempstr = "";
                    while (str[stringcounter] != '\n' && str[stringcounter] != '\0') {
                        tempstr += str[stringcounter];
                        stringcounter++;
                    }
                    stringcounter++;
                    toInsert.AadRate = stof(tempstr); // ONE ROW HAS BEEN READ

                insert:

                    myfile.close();
                    if (c == 1)
                    {
                        myTree.setType("ID");
                        myTree.root = myTree.insert(myTree.root, toInsert.Id, lines, CSVpaths[count]);
                    }

                    else if (c == 2)
                    {
                        myTree.setType("Year");
                        myTree.root = myTree.insert(myTree.root, toInsert.Year, lines, CSVpaths[count]);
                    }

                    else if (c == 6)
                    {
                        myTree.setType("Deaths");
                        myTree.root = myTree.insert(myTree.root, toInsert.Deaths, lines, CSVpaths[count]);
                    }

                    lines++;
                }
                else
                {
                    myfile.close();
                    break;
                }

            }

            count++;
        }
    }
    else if (c == 4 || c == 5 || c == 3)
    {
        avl_tree<string> myTree;

        while (count < 2)
        {

            stringcounter = 0;
            str = ""; tempstr = "";
            int lines = 1;

            while (1)
            {
                myfile.open(CSVpaths[count]);

                //for (int i = 0; i < lines + 1; i++) // +1 to skip 1st line
                //{
                //    str = "";
                //    getline(myfile, str); // reading specific line
                //}

                GotoLine(myfile, lines + 1);
                str = "";
                getline(myfile, str);

                if (str != "")
                {
                    stringcounter = 0;
                    tempstr = "";

                    tempstr = "";
                    while (str[stringcounter] != ',') {
                        tempstr += str[stringcounter];
                        stringcounter++;
                    }
                    toInsert.Id = stoi(tempstr);

                    if (c == 1)
                        goto insert1;

                    stringcounter++;
                    tempstr = "";
                    while (str[stringcounter] != ',') {
                        tempstr += str[stringcounter];
                        stringcounter++;
                    }
                    toInsert.Year = stoi(tempstr);

                    if (c == 2)
                        goto insert1;
                    stringcounter++;
                    if (str[stringcounter] == '"') {
                        stringcounter++; // cause of " character
                        tempstr = "";
                        while (str[stringcounter] != '"') {
                            tempstr += str[stringcounter];
                            stringcounter++;
                        }
                        stringcounter++;
                    }
                    else {
                        tempstr = "";
                        while (str[stringcounter] != ',') {
                            tempstr += str[stringcounter];
                            stringcounter++;
                        }
                    }
                    toInsert.CauseName113 = tempstr;

                    if (c == 3)
                        goto insert1;
                    stringcounter++;
                    tempstr = "";
                    while (str[stringcounter] != ',') {
                        tempstr += str[stringcounter];
                        stringcounter++;
                    }
                    toInsert.CauseName = tempstr;

                    if (c == 4)
                        goto insert1;
                    stringcounter++;
                    tempstr = "";
                    while (str[stringcounter] != ',') {
                        tempstr += str[stringcounter];
                        stringcounter++;
                    }
                    toInsert.State = tempstr;

                    if (c == 5)
                        goto insert1;

                    // cout << "FIFTH Read = " << tempstr << endl;
                    stringcounter++;
                    tempstr = "";
                    while (str[stringcounter] != ',') {
                        tempstr += str[stringcounter];
                        stringcounter++;
                    }
                    toInsert.Deaths = stoi(tempstr);

                    if (c == 6)
                        goto insert1;

                    stringcounter++;
                    tempstr = "";
                    while (str[stringcounter] != '\n' && str[stringcounter] != '\0') {
                        tempstr += str[stringcounter];
                        stringcounter++;
                    }
                    stringcounter++;
                    toInsert.AadRate = stof(tempstr); // ONE ROW HAS BEEN READ

                insert1:

                    myfile.close();
                    if (c == 4)
                    {
                        myTree.setType("CauseName");
                        myTree.root = myTree.insert(myTree.root, toInsert.CauseName, lines, CSVpaths[count]);
                    }

                    else if (c == 5)
                    {
                        myTree.setType("State");
                        myTree.root = myTree.insert(myTree.root, toInsert.State, lines, CSVpaths[count]);
                    }
                    else if (c == 3)
                    {
                        myTree.setType("CauseName113");
                        myTree.root = myTree.insert(myTree.root, toInsert.CauseName113, lines, CSVpaths[count]);
                    }

                    lines++;
                }
                else
                {
                    myfile.close();
                    break;
                }

            }

            count++;
        }
    }
    else if (c == 7)
    {
        avl_tree<float> myTree;

        while (count < 2)
        {

            stringcounter = 0;
            str = ""; tempstr = "";
            int lines = 1;

            while (1)
            {
                myfile.open(CSVpaths[count]);

                //for (int i = 0; i < lines + 1; i++) // +1 to skip 1st line
                //{
                //    str = "";
                //    getline(myfile, str); // reading specific line
                //}

                GotoLine(myfile, lines + 1);
                str = "";
                getline(myfile, str);

                if (str != "")
                {
                    stringcounter = 0;
                    tempstr = "";

                    tempstr = "";
                    while (str[stringcounter] != ',') {
                        tempstr += str[stringcounter];
                        stringcounter++;
                    }
                    toInsert.Id = stoi(tempstr);

                    if (c == 1)
                        goto insert2;

                    stringcounter++;
                    tempstr = "";
                    while (str[stringcounter] != ',') {
                        tempstr += str[stringcounter];
                        stringcounter++;
                    }
                    toInsert.Year = stoi(tempstr);

                    if (c == 2)
                        goto insert2;
                    stringcounter++;
                    if (str[stringcounter] == '"') {
                        stringcounter++; // cause of " character
                        tempstr = "";
                        while (str[stringcounter] != '"') {
                            tempstr += str[stringcounter];
                            stringcounter++;
                        }
                        stringcounter++;
                    }
                    else {
                        tempstr = "";
                        while (str[stringcounter] != ',') {
                            tempstr += str[stringcounter];
                            stringcounter++;
                        }
                    }
                    toInsert.CauseName113 = tempstr;

                    if (c == 3)
                        goto insert2;
                    stringcounter++;
                    tempstr = "";
                    while (str[stringcounter] != ',') {
                        tempstr += str[stringcounter];
                        stringcounter++;
                    }
                    toInsert.CauseName = tempstr;

                    if (c == 4)
                        goto insert2;
                    stringcounter++;
                    tempstr = "";
                    while (str[stringcounter] != ',') {
                        tempstr += str[stringcounter];
                        stringcounter++;
                    }
                    toInsert.State = tempstr;

                    if (c == 5)
                        goto insert2;

                    // cout << "FIFTH Read = " << tempstr << endl;
                    stringcounter++;
                    tempstr = "";
                    while (str[stringcounter] != ',') {
                        tempstr += str[stringcounter];
                        stringcounter++;
                    }
                    toInsert.Deaths = stoi(tempstr);

                    if (c == 6)
                        goto insert2;

                    stringcounter++;
                    tempstr = "";
                    while (str[stringcounter] != '\n' && str[stringcounter] != '\0') {
                        tempstr += str[stringcounter];
                        stringcounter++;
                    }
                    stringcounter++;
                    toInsert.AadRate = stof(tempstr); // ONE ROW HAS BEEN READ

                insert2:

                    myfile.close();
                    if (c == 7)
                    {
                        myTree.setType("DeathRate");
                        myTree.root = myTree.insert(myTree.root, toInsert.AadRate, lines, CSVpaths[count]);
                    }

                    lines++;
                }
                else
                {
                    myfile.close();
                    break;
                }

            }

            count++;
        }
    }
}


void main_menu()
{
    //1. ID
    //2. Year
    //3. Cause 113
    //4. Cause Name
    //5. Sate
    //6. Deaths
    //7. AAd rate

    int num = 0;
    int c = 0;

    int Id = 0; int Year = 0; int Deaths = 0;
    string CauseName113{}; string CauseName{}; string State{};
    float AadRate = 0.0;

    cout << "\nWelcome to AVL Tree";



    while (1)
    {

        cout << "\n1. ID\n2. Year\n3. Cause Name 113\n4. Cause Name\n5. State\n6. Deaths\n7. Death Rate\n0. To exit";

        do
        {
            cout << "\nEnter Number for Indexing: ";
            cin >> num;
        } while (num < 0 || num > 7);

        if (num == 0)
            break;

        AVLtree_maker(num);

        while (1)
        {
            if (num == 1)
            {
                string type = "ID";
                avl_tree<int> a(type);
                a.root = getNode<int>(MakeRootPath(type));

                cout << "\n1. Point Search \n2. Range Search \n3. Update Key \n4. Delete Key\n0. Change Index";
                cout << "\nSelect your option: ";
                cin >> c;

                if (c == 1)
                {
                    cout << "\nEnter ID: ";
                    cin >> Id;
                    a.search(a.root, Id, 1);
                }

                else if (c == 2)
                {
                    int u_range, d_range;

                    cout << "\n Starting Range: ";
                    cin >> u_range;

                    cout << "\n Ending Range: ";
                    cin >> d_range;

                    for (int i = u_range; i <= d_range; i++)
                    {
                        a.search(a.root, i, 1);
                    }

                }

                else if (c == 3)
                {
                    cout << "\nEnter ID: ";
                    cin >> Id;
                    a.update(a.root, Id);
                }

                else if (c == 4)
                {
                    cout << "\nEnter ID: ";
                    cin >> Id;
                    a.Delete(a.root, Id);
                }

                else if (c == 0)
                    break;

            }
            else if (num == 2)
            {
                string type = "Year";
                avl_tree<int> a(type);
                a.root = getNode<int>(MakeRootPath(type));

                cout << "\n1. Point Search \n2. Range Search \n3. Update Key \n4. Delete Key\n0. Change Index";
                cout << "\nSelect your option: ";
                cin >> c;

                if (c == 1)
                {
                    cout << "\nEnter Year: ";
                    cin >> Year;
                    a.search(a.root, Year, 1);
                }

                else if (c == 2)
                {
                    int u_range, d_range;

                    cout << "\n Starting Range: ";
                    cin >> u_range;

                    cout << "\n Ending Range: ";
                    cin >> d_range;

                    for (int i = u_range; i <= d_range; i++)
                    {
                        a.search(a.root, i, 1);
                    }

                }

                else if (c == 3)
                {
                    cout << "\nEnter Year: ";
                    cin >> Year;
                    a.update(a.root, Year);
                }

                else if (c == 4)
                {
                    cout << "\nEnter Year: ";
                    cin >> Year;
                    a.Delete(a.root, Year);
                }

                else if (c == 0)
                    break;

            }
            else if (num == 3)
            {
                string type = "CauseName113";
                avl_tree<string> a(type);
                a.root = getNode<string>(MakeRootPath(type));

                cout << "\n1. Point Search \n2. Range Search \n3. Update Key \n4. Delete Key\n0. Change Index";
                cout << "\nSelect your option: ";
                cin >> c;

                if (c == 1)
                {
                    cout << "\nEnter Cause Name 113: ";
                    cin >> CauseName113;
                    a.search(a.root, CauseName113, 1);
                }

                else if (c == 2)
                {
                    string u_range, d_range;

                    cout << "\n Starting Range: ";
                    cin >> u_range;

                    cout << "\n Ending Range: ";
                    cin >> d_range;

                    for (int i = str_val(u_range); i <= str_val(d_range); i++)
                    {
                        a.search(a.root, to_string(i), 1);
                    }

                }

                else if (c == 3)
                {
                    cout << "\nEnter Cause Name 113: ";
                    cin >> CauseName113;
                    a.update(a.root, CauseName113);
                }

                else if (c == 4)
                {
                    cout << "\nEnter Cause Name 113: ";
                    cin >> CauseName113;
                    a.Delete(a.root, CauseName113);
                }

                else if (c == 0)
                    break;

            }
            else if (num == 4)
            {
                string type = "CauseName";
                avl_tree<string> a(type);
                a.root = getNode<string>(MakeRootPath(type));

                cout << "\n1. Point Search \n2. Range Search \n3. Update Key \n4. Delete Key\n0. Change Index";
                cout << "\nSelect your option: ";
                cin >> c;

                if (c == 1)
                {
                    cout << "\nEnter Cause Name: ";
                    cin >> CauseName113;
                    a.search(a.root, CauseName113, 1);
                }

                else if (c == 2)
                {
                    string u_range, d_range;

                    cout << "\n Starting Range: ";
                    cin >> u_range;

                    cout << "\n Ending Range: ";
                    cin >> d_range;

                    for (int i = str_val(u_range); i <= str_val(d_range); i++)
                    {
                        a.search(a.root, to_string(i), 1);
                    }

                }

                else if (c == 3)
                {
                    cout << "\nEnter Cause Name: ";
                    cin >> CauseName113;
                    a.update(a.root, CauseName113);
                }

                else if (c == 4)
                {
                    cout << "\nEnter Cause Name: ";
                    cin >> CauseName113;
                    a.Delete(a.root, CauseName113);
                }

                else if (c == 0)
                    break;

            }
            else if (num == 5)
            {
                string type = "State";
                avl_tree<string> a(type);
                a.root = getNode<string>(MakeRootPath(type));

                cout << "\n1. Point Search \n2. Range Search \n3. Update Key \n4. Delete Key\n0. Change Index";
                cout << "\nSelect your option: ";
                cin >> c;

                if (c == 1)
                {
                    cout << "\nEnter State: ";
                    cin >> State;
                    a.search(a.root, State, 1);
                }

                else if (c == 2)
                {
                    string u_range, d_range;

                    cout << "\n Starting Range: ";
                    cin >> u_range;

                    cout << "\n Ending Range: ";
                    cin >> d_range;

                    for (int i = str_val(u_range); i <= str_val(d_range); i++)
                    {
                        a.search(a.root, to_string(i), 1);
                    }

                }

                else if (c == 3)
                {
                    cout << "\nEnter State: ";
                    cin >> State;
                    a.update(a.root, State);
                }

                else if (c == 4)
                {
                    cout << "\nEnter State: ";
                    cin >> State;
                    a.Delete(a.root, State);
                }

                else if (c == 0)
                    break;

            }
            else if (num == 6)
            {
                string type = "Deaths";
                avl_tree<int> a(type);
                a.root = getNode<int>(MakeRootPath(type));

                cout << "\n1. Point Search \n2. Range Search \n3. Update Key \n4. Delete Key\n0. Change Index";
                cout << "\nSelect your option: ";
                cin >> c;

                if (c == 1)
                {
                    cout << "\nEnter Deaths: ";
                    cin >> Deaths;
                    a.search(a.root, Deaths, 1);
                }

                else if (c == 2)
                {
                    int u_range, d_range;

                    cout << "\n Starting Range: ";
                    cin >> u_range;

                    cout << "\n Ending Range: ";
                    cin >> d_range;

                    for (int i = u_range; i <= d_range; i++)
                    {
                        a.search(a.root, i, 1);
                    }

                }

                else if (c == 3)
                {
                    cout << "\nEnter Deaths: ";
                    cin >> Deaths;
                    a.update(a.root, Deaths);
                }

                else if (c == 4)
                {
                    cout << "\nEnter Deaths: ";
                    cin >> Deaths;
                    a.Delete(a.root, Deaths);
                }

                else if (c == 0)
                    break;

            }
            else if (num == 7)
            {
                string type = "DeathRate";
                avl_tree<float> a(type);
                a.root = getNode<float>(MakeRootPath(type));

                cout << "\n1. Point Search \n2. Range Search \n3. Update Key \n4. Delete Key\n0. Change Index";
                cout << "\nSelect your option: ";
                cin >> c;

                if (c == 1)
                {
                    cout << "\nEnter Death Rate: ";
                    cin >> AadRate;
                    a.search(a.root, AadRate, 1);
                }

                else if (c == 2)
                {
                    float u_range, d_range;

                    cout << "\n Starting Range: ";
                    cin >> u_range;

                    cout << "\n Ending Range: ";
                    cin >> d_range;

                    for (float i = u_range; i <= d_range; i = i + 0.1)
                    {
                        a.search(a.root, i, 1);
                    }

                }

                else if (c == 3)
                {
                    cout << "\nEnter Death Rate: ";
                    cin >> AadRate;
                    a.update(a.root, AadRate);
                }

                else if (c == 4)
                {
                    cout << "\nEnter Deaths: ";
                    cin >> AadRate;
                    a.Delete(a.root, AadRate);
                }

                else if (c == 0)
                    break;

            }

        }
    }
}

//int main()
//{
//
//    //AVLtree_maker(1);
//
//    main_menu();
//
//
//    //avl_tree<string> a("State");
//
//    // a.root = getNode<string>(MakeRootPath("string"));
//
//    // a.update(a.root, "Alaska");
//
//    //// a.Delete(a.root, 2006);
//
//    // a.search(a.root, "Alaska", 1);
//
//    return 0;
//}
